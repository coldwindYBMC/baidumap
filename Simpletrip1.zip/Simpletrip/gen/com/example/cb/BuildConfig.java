/** Automatically generated file. DO NOT MODIFY */
package com.example.cb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}