package com.example.cb;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class Broadcast  {
	
	 @SuppressWarnings("deprecation")
	public  void broadcastreserve(Context context) {
		  String name;
		 int type;
		 ConnectivityManager connMgr = (ConnectivityManager) context
		            .getSystemService(Context.CONNECTIVITY_SERVICE);
		 NetworkInfo  networkinfo = connMgr.getActiveNetworkInfo();  
			 networkinfo = connMgr
		            .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		    boolean isWifiConn = networkinfo.isConnected();
		    networkinfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		    boolean isMobileConn = networkinfo.isConnected();
		    
		    type =  networkinfo.getType();
            name = null;
       
	    
            if(networkinfo !=null){
		    if(type ==0 ){
		    	 name ="δ��ѯ����������";
		    }
		     if(type ==1 ){
		    	 name ="GPRS";
		    }
		     if(type ==2 ){
		    	 name ="EDGE";
		    }
		     if(type ==3 ){
		    	 name ="UMTS";
		    }
		     if(type ==4 ){
		    	 name =" CDMA";
		    }
		     if(type ==5 ){
		    	 name ="EVDO �汾0";
		    }
		     if(type ==6 ){
		    	 name ="EVDO �汾A";
		    }
		     if(type ==7 ){
		    	 name ="1xRTT";
		    }
		     if(type ==8 ){
		    	 name ="HSDPA";
		    }
		     if(type ==9 ){
		        name ="HSUPA";
		    }
		     if(type ==10 ){
		    	 name ="HSPA";
		    }
		     if(type ==11 ){
		    	 name ="iDen";
		    }
		     if(type ==12 ){
		    	 name ="EVDO �汾B";
		    }
		     if(type ==13 ){
		    	 name ="LTE";
		    }
		     if(type ==14 ){
		    	 name ="eHRPD";
		    }
		     if(type ==15 ){
		    	 name ="HSPA+";
		    }
		    else if(type >15) {
		    	 name ="��������Ѱ��ʧ��";
		    }
            }
		    if( isWifiConn||isMobileConn){
		    	Toast.makeText(context, "����������"+" "+name + type,
						2000).show();
		    }
		    else{
		    	Toast.makeText(context, "����δ����",
						2000).show();
		    }
		
    }
}
