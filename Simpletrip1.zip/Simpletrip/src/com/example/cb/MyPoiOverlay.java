package com.example.cb;

import android.os.Handler;
import android.os.Message;

import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.overlayutil.PoiOverlay;
import com.baidu.mapapi.search.core.PoiInfo;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.poi.OnGetPoiSearchResultListener;
import com.baidu.mapapi.search.poi.PoiCitySearchOption;
import com.baidu.mapapi.search.poi.PoiDetailResult;
import com.baidu.mapapi.search.poi.PoiResult;
import com.baidu.mapapi.search.poi.PoiSearch;


public class MyPoiOverlay extends PoiOverlay {

	public PoiSearch mpoiSearch = null;

	public static String TextJians;
	public Handler handler;
	private String keyCity;
	private String keyWord;
	 
	    public MyPoiOverlay(BaiduMap baiduMap,Handler handler,String keyCity,String keyWord) {  
	        super(baiduMap); 
	        this.handler=handler;
	        this.keyCity=keyCity;
	        this.keyWord=keyWord;
	    }  
	    @Override  
	    public boolean onPoiClick(int index) {  
	        super.onPoiClick(index);  
	        return true;  
	    }  
	
	

	public void mypoiSearch() {

		
		mpoiSearch = PoiSearch.newInstance();
	
	
		OnGetPoiSearchResultListener poiListener = new OnGetPoiSearchResultListener() {
			public void onGetPoiResult(PoiResult poiResult) {
				if (poiResult.error != SearchResult.ERRORNO.NO_ERROR) {
								
					TextJians = "����ʧ��";
				} else {
					TextJians="�����ɹ�";
					Message message = new Message();
					 message.what=MainActivity.FIND_SUCCESS;
					 handler.sendMessage(message);
					 
					 mBaiduMap.clear();  
				       
				        PoiOverlay overlay = new MyPoiOverlay(mBaiduMap,handler,keyCity,keyWord);  
				      
				        mBaiduMap.setOnMarkerClickListener(overlay);  
				    
				        overlay.setData( poiResult);  
				     
				        overlay.addToMap();  
				        overlay.zoomToSpan();  
					  //mpoiSearch.destroy();
				        for (PoiInfo poi : poiResult.getAllPoi()) {  
				            if (poi.type == PoiInfo.POITYPE.BUS_LINE ||poi.type == PoiInfo.POITYPE.SUBWAY_LINE) {  
				                //˵������POIΪ������Ϣ����ȡ����POI��UID  
				                String busLineId = poi.uid;  
				                break;  
				            }  
				        }  
					  return;
				}
			 
		          
			
			}

			public void onGetPoiDetailResult(PoiDetailResult result) {
				
			
			}
		};
		
		mpoiSearch.setOnGetPoiSearchResultListener(poiListener);
		mpoiSearch.searchInCity((new PoiCitySearchOption()).city(keyCity)
				.keyword(keyWord)
			
				);	
	}
	
	}
	


