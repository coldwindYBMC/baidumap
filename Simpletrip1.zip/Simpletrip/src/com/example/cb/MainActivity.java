package com.example.cb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMapClickListener;
import com.baidu.mapapi.map.BaiduMap.OnMapLongClickListener;
import com.baidu.mapapi.map.BaiduMap.OnMarkerClickListener;
import com.baidu.mapapi.map.BaiduMap.OnMarkerDragListener;
import com.baidu.mapapi.map.BaiduMap.OnMyLocationClickListener;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.TextOptions;
import com.baidu.mapapi.model.LatLng;

public class MainActivity extends Activity {
	public static final int FIND_SUCCESS = 1;
	public static final int ADD_WORD=2;
	public static final int ADD_COORDINATE=3;
	public static MapView mMapView = null;
	public Boolean ButtonRoadft =false;
	public LocationClient mLocationClient = null;
	public Boolean ButtonWeixft = false;
	public int num = 0;
	public Bundle markinfo;
	public static TextView text;
	public static BaiduMap mBaiduMap;
	private Button ButtonWeix;
	private Button ButtonJiaot;
	private Button ButtonJiaos;
	private Button ButtonGongj,ButtonAddword,ButtonRoad;
	private int addbwNum = ADD_COORDINATE;
	public String keyCity;
	public String keyWord;

	private EditText EditCity;
	private EditText EditWord, OverlayText;
	private Button ButtonOK;
	BitmapDescriptor bitmap;
	private Boolean jtTF = false;

	public static MyLocationData locData;
	public static String add;
	

	@SuppressWarnings("static-access")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		SDKInitializer.initialize(getApplicationContext());
	

		setContentView(R.layout.activity_main);

		mMapView = (MapView) findViewById(R.id.bmapView);
		text = (TextView) findViewById(R.id.textView1);
		ButtonWeix = (Button) findViewById(R.id.weix);
		ButtonJiaot = (Button) findViewById(R.id.jiaot);
		ButtonJiaos = (Button) findViewById(R.id.jians);
		ButtonGongj = (Button) findViewById(R.id.gongj);
		EditCity = (EditText) findViewById(R.id.city);
		EditWord = (EditText) findViewById(R.id.word);
		ButtonOK = (Button) findViewById(R.id.OK);
		ButtonAddword=(Button) findViewById(R.id.addword);
		ButtonRoad=(Button) findViewById(R.id.addroad);
		Broadcast bro = new Broadcast();
		bro.broadcastreserve(getApplicationContext());

		mBaiduMap = mMapView.getMap();

		mBaiduMap.setMyLocationEnabled(true);
		mLocationClient = new LocationClient(getApplicationContext());

		mLocationClient.registerLocationListener(new MyLocationListenner());
		InitLocation.initLocation(mLocationClient);
		mLocationClient.start();
		// 长按监听注册
		mBaiduMap.setOnMapLongClickListener(listener);
		// 长按监听注册
		mBaiduMap.setOnMarkerClickListener(listener2);
		// 长按监听注册
		mBaiduMap.setOnMyLocationClickListener(listener3);
		//地图触摸监听注册
		mBaiduMap.setOnMyLocationClickListener(listener4);

		// 公交监听
		ButtonGongj.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				Intent intent = new Intent(MainActivity.this, Compass.class);
				startActivity(intent);

			}
		});
		// 监听按钮监听
		ButtonJiaos.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (EditCity.getVisibility() == View.GONE) {
					EditCity.setVisibility(View.VISIBLE);
					EditWord.setVisibility(View.VISIBLE);
					ButtonOK.setVisibility(View.VISIBLE);
				} else if (EditCity.getVisibility() == View.VISIBLE) {
					EditCity.setVisibility(View.GONE);
					EditWord.setVisibility(View.GONE);
					ButtonOK.setVisibility(View.GONE);
				}

			}

		});
		// 监听按钮监听
				ButtonRoad.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if(ButtonRoadft == false){
						// 将底图标注设置为隐藏
						Toast.makeText(getApplicationContext(), "底图道路", 2000)
						.show();
						 ButtonRoadft =true;
						   mBaiduMap.showMapPoi(false);
						   ButtonRoad.setText("关闭底图");
						}
						else{
							 ButtonRoadft =false;
							 mBaiduMap.showMapPoi(true);
							 ButtonRoad.setText("开启底图");
						}
					
					}});
		// 确认键监�?
		ButtonOK.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				keyCity = EditCity.getText().toString();
				keyWord = EditWord.getText().toString();
				if (EditCity.getVisibility() == View.VISIBLE) {
					EditCity.setVisibility(View.GONE);
					EditWord.setVisibility(View.GONE);
					ButtonOK.setVisibility(View.GONE);
				}
				MyPoiOverlay mPoisearch = new MyPoiOverlay(mBaiduMap, handler,
						keyCity, keyWord);
				mPoisearch.mypoiSearch();
			}

		});
         ButtonAddword.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if ( ButtonAddword.getText() == "添加文字"){
					 ButtonAddword.setText("添加标识");
				    addbwNum =ADD_COORDINATE;
					
				} else {
					 ButtonAddword.setText("添加文字");
					addbwNum =ADD_WORD;
				}
				
			}
        	 
         });
		// 卫星图监听
		ButtonWeix.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				if (ButtonWeixft== false) {
					ButtonWeix.setText("卫星图");
					ButtonWeixft=true;
					mBaiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE);
				} else {
					ButtonWeix.setText("普通图");				
					ButtonWeixft=false;
					mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
				}

			}
		});
		// 交通图监听
		ButtonJiaot.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				//
				if (jtTF == false) {
					Toast.makeText(getApplicationContext(), "交通图开启", 2000)
							.show();
					mBaiduMap.setTrafficEnabled(true);				
					jtTF = true;
				} else {
					Toast.makeText(getApplicationContext(), "交通图关闭", 2000)
							.show();
					mBaiduMap.setTrafficEnabled(false);
					jtTF = false;
				}
			}

		});
		//调用BaiduMap对象的setOnMarkerDragListener方法设置marker拖拽的监听
		mBaiduMap.setOnMarkerDragListener(new OnMarkerDragListener() {
		    public void onMarkerDrag(Marker marker) {
		        //拖拽中
		    }
		    public void onMarkerDragEnd(final Marker marker) {
		    	 //开始拖拽
		    	Toast.makeText(getApplicationContext(),"已成功设定标志物", 2000).show();  
		    	
		    }
		    public void onMarkerDragStart(Marker marker) {
		        //开始拖拽
		    	Toast.makeText(getApplicationContext(),"重新设定标志物", 2000).show();  
		    }
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	// 地图长按事件监听回调函数
	OnMapLongClickListener listener = new OnMapLongClickListener() {
		/**
		 * 
		 * @param point
		 *            长按的地理坐标
		 */
		public void onMapLongClick(final LatLng point) {
			num++;
			// 构建Marker图标

			if (num % 10 == 1 || num % 10 == 2) {
				bitmap = BitmapDescriptorFactory
						.fromResource(R.drawable.icon_marka);
			} else if (num % 10 == 3 || num % 10 == 4) {
				bitmap = BitmapDescriptorFactory
						.fromResource(R.drawable.icon_markb);
			} else if (num % 10 == 5 || num % 10 == 6) {
				bitmap = BitmapDescriptorFactory
						.fromResource(R.drawable.icon_markc);
			} else if (num % 10 == 7 || num % 10 == 8) {
				bitmap = BitmapDescriptorFactory
						.fromResource(R.drawable.icon_markd);
			} else if (num % 10 == 9 || num % 10 == 0) {
				bitmap = BitmapDescriptorFactory
						.fromResource(R.drawable.icon_marke);
			}

			final EditText edittext = new EditText(getApplicationContext());
			 edittext.setBackgroundResource(R.drawable.popup);
			// 创建InfoWindow , 传入 view， 地理坐标， y 轴偏移量
			 InfoWindow mInfoWindow2 = new InfoWindow(edittext, point, -47);
			
			mBaiduMap.showInfoWindow(mInfoWindow2);
			//获取edittext光标
			edittext.requestFocus();
		
			
			edittext.setOnEditorActionListener(new OnEditorActionListener() {
				public boolean onEditorAction(TextView v, int actionId,
						KeyEvent event) {
			
					// 构建MarkerOption，用于在地图上添加Marker
					mBaiduMap.hideInfoWindow();	
			if(addbwNum==ADD_COORDINATE){
					OverlayOptions option = new MarkerOptions()
					        .position(point)
					        .draggable(true)  //设置手势拖拽
					        .title(edittext.getText().toString()+" ")					       
							.icon(bitmap);
					// 在地图上添加Marker，并显示
					mBaiduMap.addOverlay(option);
			}
			if(addbwNum==ADD_WORD){
					OverlayOptions textOption = new TextOptions()
							.bgColor(0xAAFFFF00).
							 fontSize(24)
							.fontColor(0xFFFF00FF)
							.text(edittext.getText().toString()+" ")
							.rotate(-10)
							.position(point);				
					// 在地图上添加该文字对象并显示
					mBaiduMap.addOverlay(textOption);
			}
					return false;
				}
			});

		}
	};
	OnMarkerClickListener listener2 = new OnMarkerClickListener() {
		/**
		 * 地图 Marker 覆盖物点击事件监听函数
		 * 
		 * @param marker
		 *            被点击的 marker
		 * @return
		 */
		public boolean onMarkerClick(final Marker marker) {
			// 创建InfoWindow展示的view
			Button button = new Button(getApplicationContext());
			button.setBackgroundResource(R.drawable.popup);
			button.setText(marker.getTitle());
			// 创建InfoWindow , 传入 view， 地理坐标， y 轴偏移量
			InfoWindow mInfoWindow = new InfoWindow(button,
					marker.getPosition(), -47);
			Toast.makeText(getApplicationContext(), "点击提示框可删除改标记", 2000)
			.show();
			// 显示InfoWindow
			mBaiduMap.showInfoWindow(mInfoWindow);
			button.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					marker.remove();
					num--;
					Toast.makeText(getApplicationContext(), "剩余"+num+"个", 2000)
					.show();	
					mBaiduMap.hideInfoWindow();
				}
				
			});
			return true;

		}
	};
	OnMyLocationClickListener listener3 = new OnMyLocationClickListener() {
		/**
		 * 地图定位图标点击事件监听函数
		 */
		public boolean onMyLocationClick() {
			Toast.makeText(getApplicationContext(), "我的位置", 2000).show();
			return true;
		}
	};
	// MyPoiSearch 更新UI
	public Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case FIND_SUCCESS:

				Toast.makeText(getApplicationContext(), MyPoiOverlay.TextJians,
						2000).show();
				break;
			default:
				break;
			}
		}
	};

	OnMyLocationClickListener listener4 = new OnMyLocationClickListener() {  
	    /** 
	    * 地图定位图标点击事件监听函数 
	    */  
	    public boolean onMyLocationClick(){  
	    	mBaiduMap.hideInfoWindow();
	    	Toast.makeText(getApplicationContext(), "我的位置",
					2000).show();
			return false;
	    }  
	};

	public void onReceivePoi(BDLocation poiLocation) {
	}
}