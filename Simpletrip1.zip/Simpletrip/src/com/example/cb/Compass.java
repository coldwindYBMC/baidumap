package com.example.cb;

import java.math.BigDecimal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Compass extends Activity {
   private SensorManager sensormanager;

   private ImageView panel_img;
   private Button ButtonBack;
 
   private float lastRotateDegree;
  
	@SuppressWarnings("deprecation")
	protected void onCreate(Bundle savedInstanceState) {
     super.onCreate(savedInstanceState);				
     setContentView(R.layout.activity_compass);


     panel_img =(ImageView)findViewById(R.id.compass_panel);
     ButtonBack = (Button)findViewById(R.id.fanhui);
    
     sensormanager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
   
     Sensor magnticsensor = sensormanager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
     Sensor accelerometersensor = sensormanager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);


     sensormanager.registerListener(listener, magnticsensor,SensorManager.SENSOR_DELAY_UI);
     sensormanager.registerListener(listener, accelerometersensor,SensorManager.SENSOR_DELAY_UI);
    
    
     //���ؼ���
   		ButtonBack.setOnClickListener(new OnClickListener() {
   			@Override
   			public void onClick(View v) {	
   				
   				Intent intent = new Intent(Compass.this,MainActivity.class);
   				Compass.this.finish();
   				startActivity(intent);
   			    
   					}
   				});
   		
	}
	
	
	protected void onDestroy(){
		super.onDestroy();
		if(sensormanager != null){
			sensormanager.unregisterListener(listener);
		}
	}
	
		
	private SensorEventListener listener = new SensorEventListener() {
		
		float[] accelerometerValues = new float[3];
		float[] magntecValuess = new float[3];
		@Override
		public void onSensorChanged(SensorEvent event) {
			//ע�⸳ֵҪ��clone����
			if(event.sensor.getType() ==Sensor.TYPE_ACCELEROMETER){
				accelerometerValues =event.values.clone();
				
			}else if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
	          magntecValuess =event.values.clone();			
	 		}
			float [] R = new float[9];
			float [] values = new float[3];
			SensorManager.getRotationMatrix(R, null, accelerometerValues,magntecValuess);
			SensorManager.getOrientation(R, values);
			
			float rotateDegree = -(float)Math.toDegrees(values[0]);
			if(Math.abs(rotateDegree -lastRotateDegree) > 1){
				
				RotateAnimation anmiation = new RotateAnimation(lastRotateDegree,rotateDegree,
				  Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
				anmiation.setFillAfter(true);
				anmiation.setDuration(200);
				panel_img.startAnimation(anmiation);
				
			
			 lastRotateDegree =rotateDegree;
			}
		}
	
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		
			
		}
	};
}
